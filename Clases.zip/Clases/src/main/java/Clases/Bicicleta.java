/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author mairi
 */


class Bicicleta extends Vehiculo {
    
    public Bicicleta(){
        this.kilometrosRecorridos = 0;
    }
    
    @Override
    public void mover(double distancia){
        kilometrosRecorridos += distancia;
        System.out.println("La bicicleta ha recorrido " + distancia + "km");
    }
   
    @Override
    public double calcularAutonomia(){
        return -1;
    }
}