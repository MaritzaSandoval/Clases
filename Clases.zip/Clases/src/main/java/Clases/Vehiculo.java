/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author mairi
 */


abstract class Vehiculo {
    
    protected double kilometrosRecorridos;
    
    //Metodo para mover el vehiculo (puede ser sobreescrito en subclases)
    public abstract void mover(double distancia);
    
    //Metodo para calcular la autonomia (puede ser sobreescrito en subclases)
    public abstract double  calcularAutonomia();
}
